G# Firebase Studio

This is a NextJS starter in Firebase Studio.

To get started, take a look at src/app/page.tsx.

**Test change to verify updates. This is another test to ensure changes are being applied.**
