
'use server';

// This file is intentionally left blank as email is now handled
// via client-side mailto: links.
// Server-side sending logic has been removed.

    